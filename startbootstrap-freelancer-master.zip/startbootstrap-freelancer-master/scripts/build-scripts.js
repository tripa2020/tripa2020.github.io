'use strict';

const renderScripts = require('./render-scripts');

renderScripts();